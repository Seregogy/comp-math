﻿#pragma once

//  Фрагменты для реализации сбалансированных деревьев поиска - заготовка, не рабочая, доделать

#include <iostream>
#include <cassert>
#include <queue>
#include <vector>
#include <string>
#include <iterator>
#include <memory>
#include <memory_resource>
#include <initializer_list>
#include <functional>
#include <exception>
#include <algorithm>

template<typename T, class Compare = std::less<T>, class Allocator = std::allocator<T>>
class Binary_Search_Tree
{
	//  Объект для сравнения ключей. Должен удовлетворять требованию строго слабого порядка, т.е. иметь свойства:
	//    1. Для любого x => cmp(x,x) == false (антирефлексивность)
	//    2. Если cmp(x,y) == true  =>  cmp(y,x) == false (асимметричность)
	//    3. Если cmp(x,y) == cmp(y,z) == true  =>  cmp(x,z) == true  (транзитивность)
	//    4. Если cmp(x,y) == cmp(y,z) == false  =>  cmp(x,z) == false  (транзитивность несравнимости)
	//  Этим свойством обладает, к примеру, оператор <. Если нужно использовать оператор <= , который не обладает
	//     нужными свойствами, то можно использовать его отрицание и рассматривать дерево как инвертированное от требуемого.
	Compare cmp = Compare();

	//  Узел бинарного дерева, хранит ключ, три указателя и признак nil для обозначения фиктивной вершины
	class Node
	{
	public:  //  Все поля открыты (public), т.к. само определение узла спрятано в private-части дерева
		//  Возможно, добавить поле типа bool для определения того, является ли вершина фиктивной (листом)
		Node* parent;
		Node* left;
		Node* right;
		bool is_dummy = false;
		//  Хранимый в узле ключ
		T data;
		Node(T value = T(), Node* p = nullptr, Node* l = nullptr, Node* r = nullptr) : parent(p), data(value), left(l), right(r) {}
	};

	//  Стандартные контейнеры позволяют указать пользовательский аллокатор, который используется для
	//  выделения и освобождения памяти под узлы (реализует замену операций new/delete). К сожалению, есть 
	//  типичная проблема – при создании дерева с ключами типа T параметром шаблона традиционно указывается
	//  std::allocator<T>, который умеет выделять память под T, а нам нужен аллокатор для выделения/освобождения
	//  памяти под Node, т.е. std::allocator<Node>. Поэтому параметр шаблона аллокатора нужно изменить
	//  с T на Node, что и делается ниже. А вообще это одна из самых малополезных возможностей - обычно мы
	//  пользовательские аллокаторы не пишем, это редкость.

	//  Определяем тип аллокатора для Node (Allocator для T нам не подходит)
	using AllocType = typename std::allocator_traits<Allocator>::template rebind_alloc < Node >;
	//  Аллокатор для выделения памяти под объекты Node
	AllocType Alc;
	
	//  Рекурсивное клонирование дерева (не включая фиктивную вершину)
	//  Идея так себе - вроде пользуемся стандартной вставкой, хотя явное клонирование вершин было бы лучше
	void clone(Node * from, Node * other_dummy)
	{
		if (from == other_dummy)
			return;
		//	клонирование через insert? оно же будет переразвешиваться
		// Это ещё и рекурсивный проход в ширину, выраждает дево в список
		insert(from->data);	
		clone(from->right, other_dummy);
		clone(from->left, other_dummy);
	}
public:
	//  Эти типы должен объявлять контейнер - для функциональности
	using key_type = T;
	using key_compare = Compare;
	using value_compare = Compare;
	using value_type = typename T;
	using allocator_type = typename AllocType;
	using size_type = typename size_t;
	using difference_type = typename size_t;
	using pointer = typename T *;
	using const_pointer = typename const pointer;
	using reference = value_type & ;
	using const_reference = const value_type &;
	//using iterator = typename _Mybase::iterator;   //  Не нужно! Явно определили iterator внутри данного класса
	class iterator;   //  Предварительное объявление класса iterator, т.к. он определён ниже
	using const_iterator = iterator;
	using reverse_iterator = std::reverse_iterator<iterator>;
	using const_reverse_iterator = std::reverse_iterator<const_iterator>;

private:
	// Указательно на фиктивную вершину
	Node* dummy;

	//  Количесто элементов в дереве
	size_type tree_size = 0;

	// Создание фиктивной вершины - используется только при создании дерева
	inline Node* make_dummy()
	{
		// Выделяем память по размеру узла без конструирования
		dummy = Alc.allocate(1);
		
		//  Все поля, являющиеся указателями на узлы (left, right, parent) инициализируем и обнуляем
		std::allocator_traits<AllocType>::construct(Alc, &(dummy->parent));
		dummy->parent = dummy;

		std::allocator_traits<AllocType>::construct(Alc, &(dummy->left));
		dummy->left = dummy;

		std::allocator_traits<AllocType>::construct(Alc, &(dummy->right));
		dummy->right = dummy;

		// Поле bool
		std::allocator_traits<AllocType>::construct(Alc, &(dummy->is_dummy), true);
		
		//  Возвращаем указатель на созданную вершину
		return dummy;
	}

	// Создание узла дерева 
	template <typename T>
	inline Node* make_node(T&& elem, Node * parent, Node* left, Node* right)
	{
		// Создаём точно так же, как и фиктивную вершину, только для поля данных нужно вызвать конструктор
		Node * new_node = Alc.allocate(1);
		
		//  Все поля, являющиеся указателями на узлы (left, right, parent) инициализируем и обнуляем
		std::allocator_traits<AllocType>::construct(Alc, &(new_node->parent));
		new_node->parent = parent;

		std::allocator_traits<AllocType>::construct(Alc, &(new_node->left));
		new_node->left = left;

		std::allocator_traits<AllocType>::construct(Alc, &(new_node->right));
		new_node->right = right;

		// Поле bool
		std::allocator_traits<AllocType>::construct(Alc, &(new_node->is_dummy), false);

		//  Конструируем поле данных
		std::allocator_traits<AllocType>::construct(Alc, &(new_node->data), std::forward<T>(elem));

		//  Возвращаем указатель на созданную вершину
		return new_node;
	}

	// Удаление фиктивной вершины
	inline void delete_dummy(Node* node) {
		std::allocator_traits<AllocType>::destroy(Alc, &(node->parent));
		std::allocator_traits<AllocType>::destroy(Alc, &(node->left));
		std::allocator_traits<AllocType>::destroy(Alc, &(node->right));
		std::allocator_traits<AllocType>::destroy(Alc, &(node->is_dummy));
		std::allocator_traits<AllocType>::deallocate(Alc, node, 1);
	}
	
	// Удаление вершины дерева
	inline void delete_node(Node * node) {
		//  Тут удаляем поле данных (вызывается деструктор), а остальное удаляем так же, как и фиктивную
		std::allocator_traits<AllocType>::destroy(Alc, &(node->data));
		delete_dummy(node);
	}

public:
	//  Класс итератора для дерева поиска
	class iterator 
	{
		friend class Binary_Search_Tree;
	protected:
		//  Указатель на узел дерева
		Node* data;
		iterator() : data(nullptr) {};
		explicit iterator(Node* d) : data(d) {	}
		
		//  Указатель на узел дерева
		inline Node* &_data()
		{
			return data;
		}

		//  Родительский узел дерева
		inline iterator Parent() const noexcept
		{
			return iterator(data->parent);
		}
		//  Левый дочерний узел (если отсутствует, то фиктивная вершина)
		inline iterator Left() const noexcept
		{
			return iterator(data->left);
		}
		//  Правый дочерний узел (если отсутствует, то фиктивная вершина)
		inline iterator Right() const noexcept
		{
			return iterator(data->right);
		}
		//  Является ли узел дерева левым у своего родителя
		inline bool IsLeft() const noexcept
		{
			return (data->parent->left == data);
		}
		//  Является ли узел дерева правым у своего родителя
		inline bool IsRight() const noexcept
		{
			return (data->parent->right == data);
		}
		//Является ли узел фиктивной вершиной
		bool isNil() const { return data->is_dummy; }
		//  Поиск «самого левого» элемента
		iterator GetMin() {
			Node* n = data;
			if (n->is_dummy) return *this;               
			while (!n->left->is_dummy)                   
				n = n->left;
			return iterator(n);
		}
		//  Поиск «самого правого» элемента
		iterator GetMax() {
			Node* n = data;
			if (n->is_dummy) return *this;
			while (!n->right->is_dummy)
				n = n->right;
			return iterator(n);
		}
		//  Поиск следующего элемента
		iterator nextNode() const {
			if (data->is_dummy) return *this;

			if (!data->right->is_dummy) return iterator(data->right).GetMin();

			Node* current = data;
			Node* par = current->parent;
			while (!par->is_dummy && current == par->right) {
				current = par;
				par = par->parent;
			}
			return iterator(par);
		}
		//  Поиск предыдущего элемента
		iterator prevNode() const {
			if (data->is_dummy) return !data->right->is_dummy ? iterator(data->right).GetMax() : *this;

			if (!data->left->is_dummy) return iterator(data->left).GetMax();;

			Node* current = data;
			Node* par = current->parent;
			while (!par->is_dummy && current == par->left) {
				current = par;
				par = par->parent;
			}
			return iterator(par);
		}


	public:
		//  Определяем стандартные типы в соответствии с требованиями стандарта к двунаправленным итераторам
		using iterator_category = std::bidirectional_iterator_tag;
		using value_type = Binary_Search_Tree::value_type;
		using difference_type = Binary_Search_Tree::difference_type;
		using pointer = Binary_Search_Tree::pointer;
		using reference = Binary_Search_Tree::reference;

		//  Значение в узле, на который указывает итератор
		inline const T& operator*() const
		{
			return data->data;
		}
		inline const T* operator->() const { return &(data->data); }

		//  Преинкремент - следующий элемент множества
		iterator & operator++()
		{
			*this = nextNode();
			return *this;
		}
		//  Предекремент - переход на предыдущий элемент множества
		iterator & operator--()
		{
			*this = prevNode();
			return *this;
		}
		//  Постинкремент
		iterator operator++(int) {
			iterator t = *this;
			++(*this);
			return t;
		}
		//  Постдекремент
		iterator operator--(int) {
			iterator t = *this;
			--(*this);
			return t;

		}

		friend bool operator != (const iterator & it_1, const iterator & it_2)
		{
			return !(it_1 == it_2);
		}

		friend bool operator == (const iterator & it_1, const iterator & it_2)
		{
			return (it_1.data == it_2.data);
		}
		
		//  Эти операции не допускаются между прямыми и обратными итераторами
		const iterator & operator=(const reverse_iterator& it) = delete;
		bool operator==(const reverse_iterator& it) = delete;
		bool operator!=(const reverse_iterator& it) = delete;
		iterator(const reverse_iterator& it) = delete;
	};
	
	

	iterator begin() const noexcept { return iterator(dummy->left);	}
	iterator end() const noexcept { return iterator(dummy);  }

	reverse_iterator rbegin() const	noexcept { return reverse_iterator(end()); }
	reverse_iterator rend() const noexcept { return reverse_iterator(begin()); }

	Binary_Search_Tree(Compare comparator = Compare(), AllocType alloc = AllocType())
		: cmp(comparator), Alc(alloc), dummy(make_dummy()) {}

	Binary_Search_Tree(std::initializer_list<T> il) : dummy(make_dummy())
	{
		for (const auto &x : il)
			insert(x);
	}

	AllocType get_allocator() const noexcept { return Alc; }
	key_compare key_comp() const noexcept { return cmp; }
	value_compare value_comp() const noexcept { return cmp; }

	inline bool empty() const noexcept { return tree_size == 0; }

private:
	template <class RandomIterator>
	void ordered_insert(RandomIterator first, RandomIterator last, iterator position) {
		if (first == last) return;                      // вместо first >= last
		auto diff = std::distance(first, last);         // безопасное расстояние
		RandomIterator center = first;
		std::advance(center, diff / 2);                 // продвижение к центру
		iterator new_pos = insert(position, *center);   // вставка центрального элемента
		ordered_insert(first, center, position);        // левая половина
		ordered_insert(std::next(center), last, ++position); // правая половина
	}

public:
	template <class InputIterator>
	Binary_Search_Tree(InputIterator first, InputIterator last, Compare comparator = Compare(), AllocType alloc = AllocType()) : dummy(make_dummy()), cmp(comparator), Alc(alloc)
	{
		//  Проверка - какой вид итераторов нам подали на вход
		if (std::is_same<typename std::iterator_traits<InputIterator>::iterator_category, typename std::random_access_iterator_tag>::value) {
			//  Если итератор произвольного доступа, то есть надежда, что диапазон отсортирован
			//    а даже если и нет - не важно, всё равно попробуем метод деления пополам для вставки
			ordered_insert(first, last, end());
		}
		else
			std::for_each(first, last, [this](T x) { insert(x); });
	}

	Binary_Search_Tree(const Binary_Search_Tree & tree) : dummy(make_dummy())
	{	//  Размер задаём
		tree_size = tree.tree_size;
		if (tree.empty()) return;

		dummy->parent = recur_copy_tree(tree.dummy->parent, tree.dummy);
		dummy->parent->parent = dummy;

		//  Осталось установить min и max
		dummy->left = iterator(dummy->parent).GetMin()._data();
		dummy->right = iterator(dummy->parent).GetMax()._data();
	}

	private:

    //  Рекурсивное копирование дерева
	Node* recur_copy_tree(Node * source, const Node * source_dummy) 
	{
		//  Сначала создаём дочерние поддеревья
		Node* left_sub_tree;
		if (source->left != source_dummy)
			left_sub_tree = recur_copy_tree(source->left, source_dummy);
		else
			left_sub_tree = dummy;

		Node* right_sub_tree;
		if (source->right != source_dummy)
			right_sub_tree = recur_copy_tree(source->right, source_dummy);
		else
			right_sub_tree = dummy;
		
		//  Теперь создаём собственный узел
		Node* current = make_node(source->data, nullptr, left_sub_tree, right_sub_tree);
		//  Устанавливаем родителей
		if (source->right != source_dummy)
			current->right->parent = current;
		if (source->left != source_dummy)
			current->left->parent = current;
		//  Ну и всё, можно возвращать
		return current;
	}

	public:
	const Binary_Search_Tree & operator=(const Binary_Search_Tree &tree)
	{
		if (this == &tree) return *this;
		
		Binary_Search_Tree tmp{tree};
		swap(tmp);
		
		return *this;
	}

	size_type size() const { return tree_size; }

	// Обмен содержимым двух контейнеров
	void swap(Binary_Search_Tree & other) noexcept {
		std::swap(dummy, other.dummy);

		//  Обмен размера множеств
		std::swap(tree_size, other.tree_size);
	}

	//  Вставка элемента по значению. 
	std::pair<iterator, bool> insert(const T & value)
	{
		if (dummy->parent == dummy) {
			Node* newnode = make_node(value, dummy, dummy, dummy);
			dummy->parent = newnode;
			dummy->left = newnode;
			dummy->right = newnode;
			++tree_size;
			return std::make_pair(iterator(newnode), true);
		}

		Node* current = dummy->parent;
		Node* parent = dummy;
		bool isLeft = false;

		while (!current->is_dummy) {
			if (cmp(value,current->data)) {
				parent = current;
				current = current->left;
				isLeft = true;
			}
			else if (cmp(current->data,value)) {
				parent = current;
				current = current->right;
				isLeft = false;
			}
			else {
				return std::make_pair(iterator(current), false);
			}
		}

		Node* newnode = make_node(value, parent, dummy, dummy);
		if (isLeft) parent->left = newnode;
		else parent->right = newnode;


		if (dummy->left == dummy || cmp(value, dummy->left->data)) dummy->left = newnode;
		if (dummy->right == dummy || cmp(dummy->right->data, value)) dummy->right = newnode;

		++tree_size;
		return std::make_pair(iterator(newnode), true);
		
	}	
	//  Вставка элемента по значению move - семантика. 
	std::pair<iterator, bool> insert(T&& value)
	{
		if (dummy->parent == dummy) {
			Node* newnode = make_node(std::move(value), dummy, dummy, dummy);
			dummy->parent = newnode;
			dummy->left = newnode;
			dummy->right = newnode;
			++tree_size;
			return std::make_pair(iterator(newnode), true);
		}

		Node* current = dummy->parent;
		Node* parent = dummy;
		bool isLeft = false;

		while (!current->is_dummy) {
			if (cmp(value, current->data)) {
				parent = current;
				current = current->left;
				isLeft = true;
			}
			else if (cmp(current->data, value)) {
				parent = current;
				current = current->right;
				isLeft = false;
			}
			else {
				return std::make_pair(iterator(current), false);
			}
		}

		Node* newnode = make_node(std::move(value), parent, dummy, dummy);
		if (isLeft)
			parent->left = newnode;
		else
			parent->right = newnode;

		// Обновляем минимум и максимум, используя данные из нового узла
		if (dummy->left == dummy || cmp(newnode->data, dummy->left->data))
			dummy->left = newnode;
		if (dummy->right == dummy || cmp(dummy->right->data, newnode->data))
			dummy->right = newnode;

		++tree_size;
		return std::make_pair(iterator(newnode), true);
	}

	iterator insert(const_iterator position, const value_type& x) {
		if (empty())
			return insert(x).first;

		if (position == end()) {
			iterator last = --end();
			if (cmp(*last, x)) {
				if (last.Right().data->is_dummy) {
					Node* newnode = make_node(x, last.data, dummy, dummy);
					last.data->right = newnode;
					if(dummy->right == dummy || cmp(dummy->right->data, x))
						dummy->right = newnode;
					++tree_size;
					return iterator(newnode);
				}
			}
		}
		else if (position == begin()) {
			iterator first = begin();
			if (cmp(x, *first)) {
				if (first.Left().data->is_dummy) {
					Node* newnode = make_node(x, first.data, dummy, dummy);
					first.data->left = newnode;
					if (dummy->left == dummy || cmp(x, dummy->left->data))
						dummy->left = newnode;
					++tree_size;
					return iterator(newnode);
				}
			}
		}

		else {
			iterator prev = position;
			--prev;                                  
			if (cmp(*prev, x) && cmp(x, *position)) {
				if (position.Left().data->is_dummy) {
					Node* newnode = make_node(x, position.data, dummy, dummy);
					position.data->left = newnode;
					if (dummy->left == dummy || cmp(x, dummy->left->data))
						dummy->left = newnode;
					if (dummy->right == dummy || cmp(dummy->right->data, x))
						dummy->right = newnode;
					++tree_size;
					return iterator(newnode);
				}
				if (prev.Right().data->is_dummy) {
					Node* newnode = make_node(x, prev.data, dummy, dummy);
					prev.data->right = newnode;
					if (dummy->left == dummy || cmp(x, dummy->left->data))
						dummy->left = newnode;
					if (dummy->right == dummy || cmp(dummy->right->data, x))
						dummy->right = newnode;
					++tree_size;
					return iterator(newnode);
				}
			}
		}
		return insert(x).first;
	}

	//  Не самый лучший вариант.
	template <class InputIterator>
	void insert(InputIterator first, InputIterator last) {
		while (first != last) insert(*first++);
	}

	iterator find(const value_type& value) const {
		iterator current = iterator(dummy->parent);
		
		while (!current.data->is_dummy) {
			if (cmp(value, *current)) current = current.Left();
			else if (cmp(*current, value)) current = current.Right();
			else return current;
		}
		return end();
	}

	iterator lower_bound(const value_type& key) {
		iterator current{ dummy->parent }, result{ end() };
		while (!current.data->is_dummy) {
			if (!cmp(*current, key)) {
				result = current;
				current = current.Left();
			}
			else {
				current = current.Right();
			}
		}
		return result;
	}

	const_iterator lower_bound(const value_type& key) const {
		return const_iterator(const_cast<Binary_Search_Tree *>(this)->lower_bound(key));
	}

	iterator upper_bound(const value_type& key) {
		iterator current{ dummy->parent }, result{ end() };
		while (!current.data->is_dummy) {
			if (cmp(key,*current)) {
				result = current;
				current = current.Left();
			}
			else {
				current = current.Right();
			}
		}
		return result;
	}

	const_iterator upper_bound(const value_type& key) const {
		return const_iterator(const_cast<Binary_Search_Tree*>(this)->upper_bound(key));
	}

	size_type count(const value_type& key) const {
		return find(key) != end() ? 1 : 0;
	}

	std::pair<const_iterator, const_iterator> equal_range(const value_type& key) const {
		return { lower_bound(key), upper_bound(key) };
	}

protected:
	//  Удаление листа дерева. Возвращает количество удалённых элементов
	size_type delete_leaf(iterator leaf) {
		Node* node = leaf._data();
		if (!(node->left->is_dummy && node->right->is_dummy))
			throw std::logic_error("У листа есть потомки");
		Node* parent = node->parent;

		if (parent == dummy)
			dummy->parent = parent;
		else{
			if (parent->left == node)
				parent->left = dummy;
			else
				parent->right = dummy;
		}

		delete_node(node);
		--tree_size;
		if (dummy->parent == dummy) {
			dummy->left = dummy;
			dummy->right = dummy;
		}
		else {
			dummy->left = iterator(dummy->parent).GetMin()._data();
			dummy->right = iterator(dummy->parent).GetMax()._data();
		}
		return 1;
	}

	//  Меняет местами текущий узел и максимальный в левом поддеревею Возвращает тот же итератор, но теперь он без правого поддерева
	iterator replace_with_max_left(iterator node)
	{
		//  node имеет обоих дочерних - левое и правое поддерево, т.е. из особых вершин может быть только корнем

		//  Находим максимальный элемент слева. У него нет правого дочернего, и он не может быть корнем или самым правым
		iterator left_max = node.Left().GetMax();
		Node* A = node.data;
		Node* M = left_max.data;

		Node* parentA = A->parent;
		Node* parentM = M->parent;
		Node* leftA = A->left;
		Node* rightA = A->right;
		Node* leftM = M->left;

		if (parentM == A) {

			if (parentA == dummy) {
				dummy->parent = M;
			}
			else {
				if (parentA->left == A)
					parentA->left = M;
				else
					parentA->right = M;
			}
			M->parent = parentA;

			M->left = A;
			M->right = rightA;
			if (rightA != dummy)
				rightA->parent = M;

			A->parent = M;
			A->left = leftM;
			A->right = dummy;
			if (leftM != dummy)
				leftM->parent = A;

			return node;
		}

		if (parentM->left == M)
			parentM->left = A;
		else
			parentM->right = A;

		if (parentA == dummy) {
			dummy->parent = M;
		}
		else {
			if (parentA->left == A)
				parentA->left = M;
			else
				parentA->right = M;
		}

		A->parent = parentM;
		M->parent = parentA;

		A->left = leftM;
		A->right = dummy;
		M->left = leftA;
		M->right = rightA;

		if (leftM != dummy)
			leftM->parent = A;
		if (leftA != dummy)
			leftA->parent = M;
		if (rightA != dummy)
			rightA->parent = M;

		return node; 
	} 	


public:
	//  Удаление элемента, заданного итератором. Возвращает количество удалённых элементов (для set - 0/1)
	iterator erase(iterator elem) {
		
		if (elem.data->is_dummy)
			return end();
		Node* node = elem.data;
		bool hasLeft = !node->left->is_dummy;
		bool hasRight = !node->right->is_dummy;

		iterator next = elem;
		++next;

		if (hasLeft && hasRight) {
			replace_with_max_left(elem);
			node = elem.data;                     
			hasLeft = !node->left->is_dummy;      
			hasRight = false;                    
		}

		Node* child = (hasLeft ? node->left : node->right);
		Node* parent = node->parent;

		if (parent == dummy) {                      
			dummy->parent = child;
		}
		else {
			if (parent->left == node)
				parent->left = child;
			else
				parent->right = child;
		}
		if (child != dummy)
			child->parent = parent;

		delete_node(node);
		--tree_size;

		if (dummy->parent == dummy) {                
			dummy->left = dummy;
			dummy->right = dummy;
		}
		else {
			dummy->left = iterator(dummy->parent).GetMin()._data();
			dummy->right = iterator(dummy->parent).GetMax()._data();
		}

		return next;
	}
	
	size_type erase(const value_type& elem) {
		iterator it = find(elem);
		if (it.isNil())
			return 0;
		erase(it);
		return 1;
	}
	
	//  Проверить!!!
	iterator erase(const_iterator first, const_iterator last) {
		while (first != last)
			first = erase(first);
		return last;
	}

	//Если передавать по ссылкам,все хорошо. Конструктор копий принескольких деревьях ломается.
	friend bool operator== (const Binary_Search_Tree<T> &tree_1, const Binary_Search_Tree<T> & tree_2)
	{
		auto i = tree_1.begin(), ii = tree_2.begin();
		for (; (i != tree_1.end()) && (ii != tree_2.end()); ++i, ++ii)
		{
			if (*i != *ii)
				return false;
		}
		return i == tree_1.end() && ii == tree_2.end();
	}

	//  Очистка дерева (без удаления фиктивной вершины)
	void clear() {
		Free_nodes(dummy->parent);
		tree_size = 0;
		dummy->parent = dummy->left = dummy->right = dummy;
	}

private:
	//  Рекурсивное удаление узлов дерева, не включая фиктивную вершину
	void Free_nodes(Node* node)
	{ 
		if (node != dummy)
		{
			Free_nodes(node->left);
			Free_nodes(node->right);
			delete_node(node);
		}
	}
	
public:
	~Binary_Search_Tree()
	{
		clear(); // рекурсивный деструктор
		delete_dummy(dummy);
	}
};

template <class Key, class Compare, class Allocator>
void swap(Binary_Search_Tree<Key, Compare, Allocator>& x, Binary_Search_Tree<Key, Compare, Allocator>& y) noexcept(noexcept(x.swap(y))) {
	x.swap(y);
};


template <class Key, class Compare, class Allocator>
bool operator==(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	typename Binary_Search_Tree<Key, Compare, Allocator>::const_iterator it1{ x.begin() }, it2{ y.begin() };
	while (it1 != x.end() && it2 != y.end() && *it1 == *it2) {
		++it1; ++it2;
	}

	return it1 == x.end() && it2 == y.end();
}

template <class Key, class Compare, class Allocator>
bool operator<(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	
	typename Binary_Search_Tree<Key, Compare, Allocator>::const_iterator it1{ x.begin() }, it2{ y.begin() };
	while (it1 != x.end() && it2 != y.end() && *it1 == *it2) {
		++it1; ++it2;
	}

	if (it1 == x.end())
		return it2 != y.end();
	
	return it2 != y.end() && *it1 < *it2;
}

template <class Key, class Compare, class Allocator>
bool operator!=(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	return !(x == y);
}

template <class Key, class Compare, class Allocator>
bool operator>(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	return y < x;
}

template <class Key, class Compare, class Allocator>
bool operator>=(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	return !(x<y);
}

template <class Key, class Compare, class Allocator>
bool operator<=(const Binary_Search_Tree<Key, Compare, Allocator>& x, const Binary_Search_Tree<Key, Compare, Allocator>& y) {
	return   !(y < x);
}



