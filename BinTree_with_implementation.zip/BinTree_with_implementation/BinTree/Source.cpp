#include <iostream>
#include <set>
#include <iterator>
#include <vector>
#include <list>
#include <algorithm>
#include <iterator>
#include <random>
#include "BStree.h"

using namespace std;

template<typename InputIter>
void print(InputIter first, InputIter last) {

	if (std::is_same<typename iterator_traits<InputIter>::iterator_category, std::random_access_iterator_tag>::value) {
		cout << "Random access iterator range : ";
		while (first != last)
			cout << *first++ << " ";
		cout << endl;
	}
	else {
		cout << "Any input iterator range : ";
		while (first != last)
			cout << *first++ << " ";
		cout << endl;
	}
}

int main() {

	std::setlocale(LC_ALL, "RUSSIAN");

	const size_t sz = 15;
	vector<int> v;
	v.reserve(sz);
	std::random_device rd;  
	std::mt19937 gen(rd()); 
	std::uniform_int_distribution<> dis(0,+1000);
	generate_n(back_inserter(v), sz, [&]() {return (dis(gen) % 5000); });
	sort(v.begin(), v.end());
	cout << "\n -------------------------------- \n";
	copy(v.begin(), v.end(), ostream_iterator<int>(cout, " "));
	cout << "\n -------------------------------- \n";
	set<int> bb(v.begin(), v.end());
	print(bb.begin(), bb.end());
	Binary_Search_Tree<int> bst;
	cout << bst.size() << endl;
	cout << " -------------------------------- \n";
	for (int x : v) {
		bst.insert(x);
	}
	cout << "������ ����� �������: " << bst.size() << endl;

	print(bst.begin(), bst.end());

	//���� ������ ������� �� bb
	int key = *bb.begin(); 
	auto it = std::find(bst.begin(), bst.end(), key);
	cout << "std::find for " << key << ": ";
	if (it != bst.end())
		cout << "found" << endl;
	else
		cout << "not found" << endl;

	//��� �������������� ��������
	int missing = -1;
	auto it2 = std::find(bst.begin(), bst.end(), missing);
	cout << "std::find for " << missing << ": ";
	if (it2 == bst.end())
		cout << "not found (correct)" << endl;
	else
		cout << "found (error)" << endl;

	//������� ���������, ������� threshold
	int threshold = 500;
	int count = std::count_if(bst.begin(), bst.end(),
		[threshold](int val) { return val > threshold; });
	cout << "std::count_if (> " << threshold << "): " << count << endl;

	//���� �����, �� ��� �������� set
	int count_set = std::count_if(bb.begin(), bb.end(),
		[threshold](int val) { return val > threshold; });
	cout << "Same for std::set: " << count_set << endl;


	#ifdef _WIN32
		system("pause");
	#endif //_WIN32
	return 0;
}